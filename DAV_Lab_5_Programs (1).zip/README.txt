DAV LAB - 5 JUPYTER PROGRAMS

1. Open Jupyter Notebook.
2. Open each .ipynb file.
3. Run all cells using Kernel > Restart Kernel and Run All (or Run All).
4. Save the notebook after the outputs appear.
5. Upload the five .ipynb files to your GitHub repository.

Program 2 also creates sales_data.csv inside the notebook so the example is self-contained.
Program 5 uses scipy.stats.zscore, so install scipy if needed: pip install scipy
